exports.fn = function(req, res, pathname) {
  // 文件路径
  var filePath = '../web/api' + pathname;
  filePath = filePath.replace('.do', '.js');
  // 辨别接口是否存在
  var state = true;
  try{
    var apiRoutes = require(filePath);
  } catch(error) {
    state = false;
  }
  if (state) {
    var request = require('./request'),
      req_get = request.get(req),
      req_cookie = request.cookie(req);
    req_get['host'] = req.headers.host.split(':')[0];

    // 获取post数据
    var formidable = require('formidable'),
      formIn = new formidable.IncomingForm();
    formIn.parse(req, function(err, req_post, req_files) {
      if (err) {
        res.writeHead(403, {'Content-Type': 'text/html'});
        res.end('服务器错误，数据处理失败');
      } else {
        apiRoutes.fn({'get':req_get,'post':req_post,'files':req_files,'cookie':req_cookie}, function(resData, resCookie){
          // 设置cookie
          if (resCookie) {
            res.setHeader("Set-Cookie", resCookie);
          }
          if (resData['refresh']) {
            res.writeHead(302, {'Location': resData['refresh']});
            res.end();
          } else {
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify(resData));
          }
        });
      }
    });
  } else {
    res.writeHead(404, {'Content-Type': 'text/html'});
    res.end('服务器错误，接口不存在');
  }
};