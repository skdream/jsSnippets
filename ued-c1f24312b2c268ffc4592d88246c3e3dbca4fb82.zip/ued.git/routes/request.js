exports.get = function(req) {
  // get类型数据
  var getData = {};
  var url = require('url');
  var queryData = url.parse(req.url, true).query;
  for (key in queryData) {
    var data_key = escape(key);
    var data_val = escape(queryData[key]);
    if (data_key) {
      getData[data_key] = data_val;
    }
  }
  return getData;
};
exports.cookie = function(req) {
  var cookie = req.headers.cookie,
    cookieDict = {};
  if (cookie) {
    var querystring = require('querystring');
    cookie = cookie
      .replace(/; /g, '&')
      .replace(/;/g, '&');
    cookieDict = querystring.parse(cookie);
  }
  return cookieDict;
};