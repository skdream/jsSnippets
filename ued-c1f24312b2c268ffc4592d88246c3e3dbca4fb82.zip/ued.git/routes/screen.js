exports.fn = function(req, res, pathname, ext) {
  var pathname_s = 0;
  if (ext == 'shtml') {
    // 解析.shtml
    var pathname_match = pathname.match(/\/([a-z]+)(\d+)\.shtml/);
    if (pathname_match) {
      pathname_s = pathname_match[2];
      pathname = pathname.replace(pathname_match[0], '/'+pathname_match[1]+'.html');
    }
  }

  // 获取主文件内容
  var fs = require('fs');
  fs.readFile('./web/screen' + pathname, 'utf-8', function(err, screenSource){
    if (err) {
      // 文件读取出错
      res.writeHead(404, {'Content-Type': 'text/html'});
      res.end('{ERROR:404:' + pathname + '}');
    } else {
      // 解析包含页面
      var includeRegExp = /\{\#include[\s]*\((.+?)\)[\s]*\}/gi,
        includeRegExp2 = /\{\#include[\s]*\((.+?)\)[\s]*\}/i,
        includeMatch = screenSource.match(includeRegExp);
      if (includeMatch) {
        for (var i=0; i<includeMatch.length; i++) {
          var includeExec = includeRegExp2.exec(includeMatch[i]),
            includeFile = './web/include/' + includeExec[1];
          try {
            var includeSource = fs.readFileSync(includeFile, 'utf-8');
          } catch(error) {
            var includeSource = '{ERROR:404:' + includeStr + '}';
          }
          screenSource = screenSource.replace(includeMatch[i], includeSource);
        }
      }
      // 获取同步数据
      var dataFile = '../web/data' + pathname.replace('.html', '.js'),
        dataState = true;
      try {
        var dataRoutes = require(dataFile);
      } catch(error) {
        dataState = false;
      }

      function resEnd(resSource, resData) {
        if (!resData) resData = {};
        // juicer
        var juicer = require('juicer');
        juicer.set('strip', false);
        var juicerSource = juicer(resSource, resData);
        // 输出
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end(juicerSource);
      }
      if (dataState) {
        var request = require('./request'),
          req_get = request.get(req),
          req_cookie = request.cookie(req);
        req_get['s'] = pathname_s;
        dataRoutes.fn({'get':req_get,'cookie':req_cookie}, function(resData, resCookie){
          // 设置cookie
          if (resCookie) {
            res.setHeader("Set-Cookie", resCookie);
          }
          // 跳转
          if (resData['refresh']) {
            res.writeHead(302, {'Location': resData['refresh']});
            res.end();
          } else {
            resEnd(screenSource, resData);
          }
        });
      } else {
        resEnd(screenSource);
      }
    }
  });
};