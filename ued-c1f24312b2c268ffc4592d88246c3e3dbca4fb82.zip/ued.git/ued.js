var port = 8250,
  http = require('http'),
  server = new http.Server();
server.on('request', function(req, res) {
  var url = require('url');
  // 解析路径
  var ext = 'html',
    pathname = url.parse(req.url)['pathname'];
  if (pathname == '/') {
    pathname += 'index.html';
  } else {
    if (pathname.indexOf('.') < 0) {
      pathname += '/index.html';
      pathname = pathname.replace(/\/\//g, '/');
    } else {
      ext = pathname.substring(pathname.lastIndexOf('.')+1);
    }
  }

  // 处理加载地址
  if (ext == 'html' || ext == 'shtml') {
    var routes = require('./routes/screen');
    routes.fn(req, res, pathname, ext);
  } else if (ext == 'do') {
    var routes = require('./routes/api');
    routes.fn(req, res, pathname);
  } else {
    res.writeHead(404, {'Content-Type': 'text/html'});
    res.end('{ERROR:404:' + pathname + '}');
  }
});
server.listen(port);
console.log('ued：'+port);