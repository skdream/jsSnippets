exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {};

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('登录超时');
      resEnd(resData);
    }
  });

  function defaultFn(){
    var upfile = require('../upload/upfile'),
      postData = reqData['post'],
      groupid = + postData['groupid'],
      blogid = + postData['blogid'],
      title = postData['title'],
      note = postData['note'],
      content = postData['content'];
    if (isNaN(groupid) || groupid <= 0) {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('请选择主题类目');
      resEnd(resData);
      return false;
    }
    if (isNaN(blogid) || blogid <= 0) {
      blogid = 0;
      var oldblogpic = '';      
    } else {
      var oldblogpic = postData['oldblogpic'];
    }
    if (title) {
      title = escape(title);
    } else {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('文章标题必须填写');
      resEnd(resData);
      return false;
    }
    if (note) note = escape(note);
    if (content) content = escape(content);
    upfile.fn(reqData['files']['blogpic'], function (error, response){
      if (!error && response) {
        var blogpic = response;
      } else if (error == 'nofile'){
        var blogpic = oldblogpic;
      } else {
        resData['refresh'] = '/result.html?msg='+encodeURIComponent(response);
        resEnd(resData);
        return false;
      }
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db'),
        dateformat = require('../../data/dateformat'),
        nowtime = dateformat.format('YY-MM-DD hh:mm:ss');
      if (blogid == 0) {
        var sql = 'insert into blog(groupid,addtime,verid,busy,userid) values('+groupid+',"'+nowtime+'",0,1,'+resData['user']['id']+')';
        uedDb.run(sql, function (error){
          if (error) {
            resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据保存出错，文章发表失败');
            resEnd(resData);
            return false;
          }
          var sql = 'select id from blog where verid=0 and busy=1 and userid='+resData['user']['id']+' order by id desc limit 0,1'
          uedDb.get(sql, function (error, response){
            if (error) {
              resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据检索出错，文章发表失败');
              resEnd(resData);
              return false;
            }
            blogid = response['id'];
            blogverFn(10);
          });
        });
      } else {
        var sql = 'update blog set groupid='+groupid+' where id='+blogid;
        uedDb.run(sql, function (error){
          blogverFn(2);
        });
      }
      function blogverFn(hotnum){
        var sql = 'insert into blogver(blogid, userid, blogpic, title, note, content, edittime) values('+
          blogid + ',' +
          resData['user']['id'] + ',' +
          '"'+ blogpic + '",' +
          '"'+ title + '",' +
          '"'+ note + '",' +
          '"'+ content + '",' +
          '"'+ nowtime + '"' +
        ')';
        uedDb.run(sql, function (error){
          if (error) {
            resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据保存出错，文章发表失败');
            resEnd(resData);
            return false;
          }
          var sql = 'select id from blogver where blogid='+blogid+' and userid='+resData['user']['id']+' and title="'+title+'" order by id desc limit 0,1'
          uedDb.get(sql, function (error, response){
            if (error) {
              resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据检索出错，文章发表失败');
              resEnd(resData);
              return false;
            }
            var verid = response['id'],
              sql = 'update blog set verid='+verid+',busy=0 where id='+blogid;
            uedDb.run(sql, function (error){
              if (error) {
                resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据保存出错，文章发表失败');
              } else {
                resData['refresh'] = '/result.html?msg='+encodeURIComponent('文章发表成功')+'&goto='+encodeURIComponent('/blog/detail'+blogid+'.shtml');
              }
              addHot(hotnum);
            });
          });
        });
      }
      function addHot(hotnum){
        // 团队加分
        var sql = 'select groupid,hot from usergroup,blog where blog.groupid=usergroup.id and blog.id='+blogid;
        uedDb.get(sql, function (error, response){
          if (error) {
            resEnd(resData);
            return false;
          }
          var hot = + response['hot'] + hotnum,
            sql = 'update usergroup set hot='+hot+' where id='+response['groupid'];
          uedDb.run(sql, function (error){
            // 个人加分
            var sql = 'select hot from user where id='+resData['user']['id'];
            uedDb.get(sql, function (error, response){
              if (error) {
                resEnd(resData);
                return false;
              }
              var hot = + response['hot'] + hotnum,
                sql = 'update user set hot='+hot+' where id='+resData['user']['id'];
              uedDb.run(sql, function (error){
                resEnd(resData);
              });
            });
          });
        });
      }
    });
  }
};