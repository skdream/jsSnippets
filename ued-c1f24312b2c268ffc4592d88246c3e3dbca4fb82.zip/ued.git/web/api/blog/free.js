exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {};

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      blogid = + getData['blogid'];
    if (isNaN(blogid) || blogid <= 0) {
      resData['refresh'] = '/';
      resEnd(resData);
      return false;
    }
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'update blog set busy=0,userid=0 where userid='+resData['user']['id']+' and id='+blogid;
    uedDb.run(sql, function (error){
      resData['refresh'] = 'detail'+blogid+'.shtml';
      resEnd(resData);
    });
  }
};