exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'remarkList': [],
    'remarkBackList': [],
    'comeon': false
  };

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      defaultFn();
    } else {
      resEnd(resData);
    }
  });

  function defaultFn(){
    var postData = reqData['post'],
      blogid = + postData['blogid'],
      page = + postData['page'];
    if (isNaN(blogid) || blogid <= 0) {
      resEnd(resData);
      return false;
    }
    if (isNaN(page) || page <= 0) page = 1;
    var pageLen = 20,
      limitStart = (page - 1) * pageLen;
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'select remark.id,content,addtime,userid,headpic,realname from remark,user where userid=user.id and remarkid=0 and blogid='+blogid+' order by remark.id desc limit '+limitStart+', '+pageLen;
    uedDb.all(sql, function (error, response){
      if (error) {
        resEnd(resData);
        return false;
      }
      if (response.length == pageLen) {
        resData['comeon'] = true;
      }
      var remarkid = '0';
      for (var i=0; i<response.length; i++) {
        remarkid += ',' + response[i]['id'];
        response[i]['content'] = unescape(response[i]['content'])
          .replace(/</g, '&lt;').replace(/>/g, '&gt;')
          .replace('\r\n', '<br>');
      }
      resData['remarkList'] = response;
      var sql = 'select remarkid,content,addtime,userid,headpic,realname from remark,user where userid=user.id and remarkid in('+remarkid+') and blogid='+blogid+' order by remark.id';
      uedDb.all(sql, function (error, response){
        if (error) {
          resEnd(resData);
          return false;
        }
        for (var i=0; i<response.length; i++) {
          response[i]['content'] = unescape(response[i]['content'])
            .replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace('\r\n', '<br>');
        }
        resData['remarkBackList'] = response;
        resEnd(resData);
      });
    });
  }
};