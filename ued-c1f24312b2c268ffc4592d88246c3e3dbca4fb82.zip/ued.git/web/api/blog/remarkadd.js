exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {};

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('登录超时');
      resEnd(resData);
    }
  });

  function defaultFn(){
    var postData = reqData['post'],
      blogid = + postData['blogid'],
      remarkid = + postData['remarkid'],
      content = postData['content'];
    if (isNaN(blogid) || blogid <= 0) {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('参数错误，评论发表失败');
      resEnd(resData);
      return false;
    }
    if (isNaN(remarkid) || remarkid <= 0) remarkid = 0;
    if (content) {
      content = escape(content);
    } else {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('请输入评论内容');
      resEnd(resData);
      return false;
    }
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      dateformat = require('../../data/dateformat'),
      nowtime = dateformat.format('YY-MM-DD hh:mm:ss'),
      sql = 'insert into remark(blogid, remarkid, userid, content, addtime) values('+
        blogid+','+remarkid+','+resData['user']['id']+',"'+content+'","'+nowtime+'"'+
      ')';
    uedDb.run(sql, function (error){
      resData['refresh'] = 'remark.html?remarkid='+remarkid;
      addHot(1);
    });
    function addHot(hotnum){
      // 团队加分
      var sql = 'select groupid,hot from usergroup,blog where blog.groupid=usergroup.id and blog.id='+blogid;
      uedDb.get(sql, function (error, response){
        if (error) {
          resEnd(resData);
          return false;
        }
        var hot = + response['hot'] + hotnum,
          sql = 'update usergroup set hot='+hot+' where id='+response['groupid'];
        uedDb.run(sql, function (error){
          // 个人加分
          var sql = 'select hot from user where id='+resData['user']['id'];
          uedDb.get(sql, function (error, response){
            if (error) {
              resEnd(resData);
              return false;
            }
            var hot = + response['hot'] + hotnum,
              sql = 'update user set hot='+hot+' where id='+resData['user']['id'];
            uedDb.run(sql, function (error){
              resEnd(resData);
            });
          });
        });
      });
    }
  }
};