exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'remarkBackList': []
  };

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      defaultFn();
    } else {
      resEnd(resData);
    }
  });

  function defaultFn(){
    var postData = reqData['post'],
      remarkid = + postData['remarkid'];
    if (isNaN(remarkid) || remarkid <= 0) {
      resEnd(resData);
      return false;
    }
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'select remarkid,content,addtime,userid,headpic,realname from remark,user where userid=user.id and remarkid='+remarkid+' order by remark.id';
    uedDb.all(sql, function (error, response){
      if (error) {
        resEnd(resData);
        return false;
      }
      for (var i=0; i<response.length; i++) {
        response[i]['content'] = unescape(response[i]['content'])
          .replace(/</g, '&lt;').replace(/>/g, '&gt;')
          .replace('\r\n', '<br>');
      }
      resData['remarkBackList'] = response;
      resEnd(resData);
    });
  }
};