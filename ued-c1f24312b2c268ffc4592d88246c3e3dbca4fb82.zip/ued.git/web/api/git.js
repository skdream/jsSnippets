exports.fn = function(reqData, resEnd) {
  var resData = {
    "resultCode": 220,
    "resultMsg": ''
  };
  var postData = reqData['post'],
    ref = postData['ref'];

  if (ref == 'refs/heads/master') {
    var domain = postData['repository']['name'];
    if (domain == 'ued') {
      var process = require('child_process');
      process.exec('cd /opt/htdocs/'+domain+'/ && git pull origin master', function (error, stdout, stderr) {
        if (error) {
          resData['resultCode'] = 240;
          resData['resultMsg'] = '命令行执行出错！';
          resEnd(resData);
        } else {
          process.exec('cd /opt/htdocs/'+domain+'/ && forever restart ued.js', function (error, stdout, stderr) {
            resData['resultMsg'] = domain + '同步成功！';
            resEnd(resData);
          });
        }
      });
    } else {
      resData['resultCode'] = 240;
      resData['resultMsg'] = '参数获取失败！';
      resEnd(resData);
    }
  } else {
    resData['resultCode'] = 240;
    resData['resultMsg'] = '不是master主分支，命令行不执行！';
    resEnd(resData);
  }
};