exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {};

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var upfile = require('../upload/upfile'),
      postData = reqData['post'],
      id = postData['id'],
      groupname = postData['groupname'],
      content = postData['content'];
    if (isNaN(id) || id <= 0) {
      id = 0;
    }
    if (groupname) {
      groupname = escape(groupname);
    } else {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('类目名称必须填写');
      resEnd(resData);
      return false;
    }
    if (content) content = escape(content);
    upfile.fn(reqData['files']['grouppic'], function (error, response){
      if (!error && response) {
        var grouppic = response;
      } else if (error == 'nofile'){
        var grouppic = '';
      } else {
        resData['refresh'] = '/result.html?msg='+encodeURIComponent(response);
        resEnd(resData);
        return false;
      }
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db');
      if (id > 0) {
        var sql = 'update usergroup set groupname="'+groupname+'",content="'+content+'"';
        if (grouppic) {
          sql += ',grouppic="'+grouppic+'"';
        }
        sql += ' where userid='+resData['user']['id']+' and id='+id;
        uedDb.run(sql, function (error){
          if (error) {
            resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据保存出错，类目修改失败');
          } else {
            resData['refresh'] = '/result.html?msg='+encodeURIComponent('类目修改成功')+'&goto='+encodeURIComponent('/group/detail'+id+'.shtml');
          }
          resEnd(resData);
        });
      } else {
        var dateformat = require('../../data/dateformat'),
          nowtime = dateformat.format('YY-MM-DD hh:mm:ss'),
          sql = 'insert into usergroup(userid, groupname, grouppic, content, addtime, hot) values('+
            resData['user']['id']+','+
            '"'+groupname+'",'+
            '"'+grouppic+'",'+
            '"'+content+'",'+
            '"'+nowtime+'",'+
            '0)';
        uedDb.run(sql, function (error){
          if (error) {
            resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据保存出错，类目创建失败');
            resEnd(resData);
          } else {
            var sql = 'select id from usergroup where userid='+resData['user']['id']+' and groupname="'+groupname+'" order by id desc';
            uedDb.get(sql, function (error, response){
              if (error) {
                resData['refresh'] = '/result.html?msg='+encodeURIComponent('类目创建成功')+'&goto='+encodeURIComponent('/');
              } else {
                resData['refresh'] = '/result.html?msg='+encodeURIComponent('类目创建成功')+'&goto='+encodeURIComponent('/group/detail'+response['id']+'.shtml');
              }
              resEnd(resData);
            });
          }        
        });
      }
    });
  }
};