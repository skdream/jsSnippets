exports.fn = function(reqData, resEnd) {
  // 初始数据
  var getData = reqData['get'],
    resData = {
      "refresh": 'http://passport.woniusite.com/?gourl=http%3A%2F%2Fued.woniu.com%2Flogin.do'
    };

  // 获取参数
  var account = getData['account'],
    timestamp = getData['timestamp'],
    username = getData['username'],
    spell = getData['spell'];

  if (account && timestamp && username && spell) {
    var key = 'SSO#!)';
  } else {
    resEnd(resData);
    return false;
  }

  var _encrymd5 = require('crypto').createHash('md5');
  _encrymd5.update(key + account + timestamp);
  var token = _encrymd5.digest('hex');

  resData['refresh'] = null;
  if (spell != token) {
    resData['errMsg'] = "登录失败！";
    resEnd(resData);
    return false;
  }
  
  // 连接数据库
  var sqlite3 = require('sqlite3'),
    userDb = new sqlite3.Database('./db/ued.db');

  // 校验用户名密码
  function selectUser(){
    var sql = 'select id,username from user where username="'+account+'"';
    userDb.get(sql, function(err, response){
      if (response) {
        setCookie(response['id'], response['username']);
      } else {
        var realname = decodeURIComponent(unescape(username)),
          sql = 'select url from weblogo order by id desc limit 0,1';
        userDb.all(sql, function (err, response){
          if (response && response.length) {
            var weblogo = response[0]['url'];
          } else {
            var weblogo = '';
          }
          var sql = 'select url,size from webbg order by id desc limit 0,1';
          userDb.all(sql, function (err, response){
            if (response && response.length) {
              var webbg = response[0]['url'],
                webbgsize = response[0]['size'];
            } else {
              var webbg = '',
                webbgsize = '100%';
            }
            var headpic = '/static/img/headpic.jpg',
              sql = 'insert into user(username,realname,headpic,weblogo,webbg,webbgsize,hot) values("'+account+'","'+realname+'","'+headpic+'","'+weblogo+'","'+webbg+'","'+webbgsize+'",0)';
            userDb.run(sql, function (err){
              selectUser();
            });
          });
        });
      }
    });
  }
  selectUser();

  // 设置cookie值
  function setCookie(uid, uname){
    var dateformat = require('../data/dateformat'),
      nowTime = dateformat.format('YY-MM-DD hh:mm:ss'),
      rand = dateformat.format('YYMMDDhhmmss') + 'R-snail-R' + Math.floor(Math.random()*10000);
    var _encrymd5 = require('crypto').createHash('md5');
    _encrymd5.update(rand);
    var usign = _encrymd5.digest('hex');
    // 写入cookie
    var today = new Date();
    var expiresTime = today.getTime() + 12 * 3600 * 1000;
    var expires = new Date(expiresTime).toGMTString();
    var resCookie = [
      'ued_userid=' + uid + ';expires=' +  expires + ';path=/;HttpOnly;',
      'ued_username=' + uname + ';expires=' +  expires + ';path=/;HttpOnly;',
      'ued_usersign=' + usign + ';expires=' +  expires + ';path=/;HttpOnly;'
    ];
    
    // 更新数据库 usersign logintime 值
    var sql = 'update user set ' +
      'usersign = "' + usign + '",' +
      'logintime = "' + nowTime + '"' +
      ' where id=' + uid;
    userDb.run(sql, function(err){
      resData['refresh'] = '/';
      resEnd(resData, resCookie);
    });
  }

};