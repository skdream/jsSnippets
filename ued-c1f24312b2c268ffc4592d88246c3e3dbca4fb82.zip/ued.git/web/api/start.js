exports.fn = function(reqData, resEnd) {
  var resData = {
    'msg': '已创建成功！'
  };
  var fs = require('fs'),
    sqlite3 = require('sqlite3');

  // 检测数据库
  fs.exists('./db/ued.db', function (state){
    var uedDb = new sqlite3.Database('./db/ued.db');
    if (state) {
      resEnd(resData);
    } else {
      // 创建表 user
      var dataSql = 'CREATE TABLE user (id integer PRIMARY KEY AUTOINCREMENT NOT NULL,'+
        'username, realname, headpic, usersign, logintime, weblogo, webbg, webbgsize, hot)';
      uedDb.run(dataSql, function (err){
        // 创建表 webbg
        var dataSql = 'CREATE TABLE webbg (id integer PRIMARY KEY AUTOINCREMENT NOT NULL,'+
          'userid, url, size)';
        uedDb.run(dataSql, function (err){
          // 创建表 weblogo
          var dataSql = 'CREATE TABLE weblogo (id integer PRIMARY KEY AUTOINCREMENT NOT NULL,'+
            'userid, url)';
          uedDb.run(dataSql, function (err){
            // 创建表 usergroup
            var dataSql = 'CREATE TABLE usergroup (id integer PRIMARY KEY AUTOINCREMENT NOT NULL,'+
              'userid, groupname, grouppic, content, grouplink, addtime, hot)';
            uedDb.run(dataSql, function (err){
              // 创建表 blog
              var dataSql = 'CREATE TABLE blog (id integer PRIMARY KEY AUTOINCREMENT NOT NULL,'+
                'groupid, addtime, verid, busy, userid)';
              uedDb.run(dataSql, function (err){
                // 创建表 blogver
                var dataSql = 'CREATE TABLE blogver (id integer PRIMARY KEY AUTOINCREMENT NOT NULL,'+
                  'blogid, userid, blogpic, title, note, content, edittime)';
                uedDb.run(dataSql, function (err){
                  // 创建表 remark
                  var dataSql = 'CREATE TABLE remark (id integer PRIMARY KEY AUTOINCREMENT NOT NULL,'+
                    'blogid, remarkid, userid, content, addtime)';
                  uedDb.run(dataSql, function (err){
                    resEnd(resData);
                  });
                });
              });
            });
          });
        });
      });
    }
  });
};