exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    "error": 0,
    "url": "",
    "message": ""
  };

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      defaultFn();
    } else {
      resData['error'] = 1;
      resData['message'] = '未登录或登录超时，请重新登录！';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var upfile = require('./upfile');
    upfile.fn(reqData['files']['imgFile'], function (error, response){
      if (!error && response) {
        resData['url'] = response;
        resEnd(resData);
      } else {
        resData['error'] = 1;
        resData['message'] = '文件上传失败';
        resEnd(resData);
      }
    });
  }
};