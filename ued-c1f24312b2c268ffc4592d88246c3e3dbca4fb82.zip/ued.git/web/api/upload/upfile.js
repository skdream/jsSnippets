exports.fn = function(upFile, callback) {
  if (upFile) {
    if (upFile['size'] > 0) {
      if (upFile['size'] / 1024 > 1024) {
        callback('bigfile', '上传的文件不得超过1M');
        return false;
      }
      var fs = require('fs'),
        dateformat = require('../../data/dateformat'),
        folder = './upfile/'+dateformat.format('YYMM'),
        ext = upFile['name'].substr(upFile['name'].lastIndexOf('.')+1);

      // 随机生成文件名
      var newName = 'snail-upfile-'+ new Date().getTime() + '-'+Math.floor(Math.random()*10000),
        _encrymd5 = require('crypto').createHash('md5');
      _encrymd5.update(newName);
      newName = _encrymd5.digest('hex');

      var filePath = folder +'/'+newName+'.'+ext;
      fs.exists(folder, function(state){
        if (state) {
          saveImg();
        } else {
          fs.mkdir(folder, function(error){
            saveImg();
          });
        }
      });

      function saveImg(){
        try {
          fs.renameSync(upFile['path'], filePath);
        } catch(e) {
          callback('lose', '上传的文件意外丢失');
          return false;
        }
        callback(null, filePath.substr(1));
      }
    } else {
      callback('nofile', '未上传文件');
    }
  } else {
    callback('nofile', '未上传文件');
  }
};