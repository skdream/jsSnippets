exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {};

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var upfile = require('../upload/upfile');
    upfile.fn(reqData['files']['headpic'], function (error, response){
      if (!error && response) {
        var headpic = response;
      } else {
        resData['refresh'] = '/result.html?msg='+encodeURIComponent(response);
        resEnd(resData);
        return false;
      }
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db'),
        sql = 'update user set headpic="'+headpic+'" where id='+resData['user']['id'];
      uedDb.run(sql, function (error){
        if (error) {
          resData['refresh'] = '/result.html?msg='+encodeURIComponent('数据保存出错，头像修改失败');
        } else {
          resData['refresh'] = '/result.html?msg='+encodeURIComponent('头像修改成功')+'&goto='+encodeURIComponent('/user/detail'+resData['user']['id']+'.shtml');
        }
        resEnd(resData);
      });
    });
  }
};