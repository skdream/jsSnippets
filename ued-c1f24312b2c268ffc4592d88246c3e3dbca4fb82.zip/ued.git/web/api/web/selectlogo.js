exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    "refresh": '/web/weblogo.html'
  };

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var id = + reqData['get']['id'];
    if (isNaN(id) || id <= 0) {
      resEnd(resData);
      return false;
    } else {
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db'),
        sql = 'select url from weblogo where id='+id;
      uedDb.get(sql, function (error, response){
        if (response) {
          var sql = 'update user set weblogo="'+response['url']+'" where id='+resData['user']['id'];
          uedDb.run(sql, function (error){
            resEnd(resData);
          });
        } else {
          resEnd(resData);
        }
      });
    }
  }
};