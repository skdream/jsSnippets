exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    "refresh": '/web/webbg.html'
  };

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('登录超时');
      resEnd(resData);
    }
  });

  function defaultFn(){
    var upfile = require('../upload/upfile'),
      upbgsize = reqData['post']['upbgsize'];
    if (upbgsize != 'auto') upbgsize = '100%';
    upfile.fn(reqData['files']['upbg'], function (error, response){
      if (!error && response) {
        var url = response;
      } else {
        resData['refresh'] = '/result.html?msg='+encodeURIComponent(response);
        resEnd(resData);
        return false;
      }
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db'),
        sql = 'insert into webbg(userid,url,size) values('+resData['user']['id']+',"'+url+'","'+upbgsize+'")';
      uedDb.run(sql, function (error){
        if (error) {
          resData['refresh'] = '/result.html?msg='+encodeURIComponent('背景图片上传失败');
          resEnd(resData);
        } else {
          var sql = 'update user set webbg="'+url+'",webbgsize="'+upbgsize+'" where id='+resData['user']['id'];
          uedDb.run(sql, function (error){
            resData['refresh'] = '/result.html?msg='+encodeURIComponent('背景图片上传成功')+'&goto=reload';
            resEnd(resData);
          });
        }
      });
    });
  }
};