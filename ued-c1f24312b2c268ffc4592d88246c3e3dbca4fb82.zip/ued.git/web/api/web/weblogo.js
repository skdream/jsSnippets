exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    "refresh": '/web/weblogo.html'
  };

  var uedcookie = require('../../data/uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/result.html?msg='+encodeURIComponent('登录超时');
      resEnd(resData);
    }
  });

  function defaultFn(){
    var upfile = require('../upload/upfile');
    upfile.fn(reqData['files']['uplogo'], function (error, response){
      if (!error && response) {
        var url = response;
      } else {
        resData['refresh'] = '/result.html?msg='+encodeURIComponent(response);
        resEnd(resData);
        return false;
      }
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db'),
        sql = 'insert into weblogo(userid,url) values('+resData['user']['id']+',"'+url+'")';
      uedDb.run(sql, function (error){
        if (error) {
          resData['refresh'] = '/result.html?msg='+encodeURIComponent('logo上传失败');
          resEnd(resData);
        } else {
          var sql = 'update user set weblogo="'+url+'" where id='+resData['user']['id'];
          uedDb.run(sql, function (error){
            resData['refresh'] = '/result.html?msg='+encodeURIComponent('logo上传成功')+'&goto=reload';
            resEnd(resData);
          });
        }
      });
    });
  }
};