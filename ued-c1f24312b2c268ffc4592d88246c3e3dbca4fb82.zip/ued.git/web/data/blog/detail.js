exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'blog': {},
    'blogver': {},
    'groupList': [],
    'verList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      blogid = + getData['s'],
      verid = + getData['ver'];
    if (isNaN(blogid) || blogid <= 0) {
      resData['refresh'] = '/';
      resEnd(resData);
      return false;
    }
    if (isNaN(verid) || verid <= 0) {
      verid = 0;
    }
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'select blog.id,verid,busy,blog.userid,groupid,groupname,grouppic from blog,usergroup where groupid=usergroup.id and blog.id=' + blogid;
    uedDb.get(sql, function (error, response){
      if (response) {
        response['groupname'] = unescape(response['groupname']);
        if (!response['grouppic']) response['grouppic'] = '/static/img/group.png';
        resData['blog'] = response;
        if (verid == 0) {
          verid = response['verid'];
        }
        if (response['busy'] == 1) {
          var sql = 'select id,headpic,realname from user where id='+response['userid'];
          uedDb.get(sql, function (error, response){
            if (response) {
              resData['busy'] = response;
            }
            verFn();
          });
        } else {
          verFn();
        }
        function verFn(){
          var sql = 'select * from blogver where id='+verid;
          uedDb.get(sql, function (error, response){
            if (error) {
              resData['refresh'] = '/';
              resEnd(resData);
              return false;
            }
            if (response) {
              response['title'] = unescape(response['title']);
              response['note'] = unescape(response['note']);
              response['content'] = unescape(response['content']);
              resData['blogver'] = response;
              var sql = 'select blogver.id,headpic,edittime from blogver,user where userid=user.id and blogid='+blogid+' order by blogver.id desc';
              uedDb.all(sql, function (error, response){
                resData['verList'] = response;
                commonFn();
              });
            } else {
              resData['refresh'] = '/';
              resEnd(resData);
              return false;
            }
          });
        }
      } else {
        resData['refresh'] = '/';
        resEnd(resData);
      }
    });
    function commonFn(){
      var common = require('../common');
      common.group(function (groupList){
        resData['groupList'] = groupList;
        resEnd(resData);
      });
    }
  }
};