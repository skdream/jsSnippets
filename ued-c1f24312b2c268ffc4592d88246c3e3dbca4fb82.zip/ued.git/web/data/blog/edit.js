exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'type': 'add',
    'blog': {},
    'groupList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      blogid = + getData['s'],
      sudo = getData['sudo'];
    if (isNaN(blogid) || blogid <= 0) {
      blogid = 0;
      resData['blog']['blogid'] = blogid;
      resData['groupid'] = getData['groupid'];
      commonFn();
    } else {
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db');
      if (sudo == 'sudo'+blogid) {
        var sql = 'update blog set busy=1,userid='+resData['user']['id']+' where id='+blogid;
        uedDb.run(sql, function (error){
          resData['refresh'] = '/blog/detail'+blogid+'.shtml';
          resEnd(resData);
        });
        return false;
      }
      var sql = 'select groupid,verid from blog where (busy=0 or userid='+resData['user']['id']+') and id=' + blogid;
      uedDb.get(sql, function (error, response){
        if (response) {
          resData['type'] = 'edit';
          resData['groupid'] = response['groupid'];
          var verid = response['verid'],
            sql = 'update blog set busy=1,userid='+resData['user']['id']+' where id='+blogid;
          uedDb.run(sql, function (error){
            if (error) {
              resData['refresh'] = '/blog/detail'+blogid+'.shtml';
              resEnd(resData);
              return false;
            }
            var sql = 'select * from blogver where id='+verid;
            uedDb.get(sql, function (error, response){
              if (error) {
                resData['refresh'] = '/blog/detail'+blogid+'.shtml';
                resEnd(resData);
                return false;
              }
              if (response) {
                response['title'] = unescape(response['title']);
                response['note'] = unescape(response['note']);
                response['content'] = unescape(response['content']);
                resData['blog'] = response;
              }
              commonFn();
            });
          });
        } else {
          resData['refresh'] = '/blog/detail'+blogid+'.shtml';
          resEnd(resData);
        }
      });
    }
    function commonFn(){
      var common = require('../common');
      common.group(function (groupList){
        resData['groupList'] = groupList;
        resEnd(resData);
      });
    }
  }
};