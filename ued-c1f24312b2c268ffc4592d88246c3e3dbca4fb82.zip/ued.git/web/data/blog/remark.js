exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'remarkid': 0
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      remarkid = + getData['remarkid'];
    if (isNaN(remarkid) || remarkid <= 0) remarkid = 0;
    resData['remarkid'] = remarkid;
    resEnd(resData);
  }
};