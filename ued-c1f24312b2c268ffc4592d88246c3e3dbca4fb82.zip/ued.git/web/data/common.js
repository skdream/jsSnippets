exports.group = function(callback) {
  // group
  var sqlite3 = require('sqlite3'),
    uedDb = new sqlite3.Database('./db/ued.db'),
    sql = 'select * from usergroup order by hot desc, id desc';
  uedDb.all(sql, function (error, response){
    for (var i=0; i<response.length; i++) {
      response[i]['groupname'] = unescape(response[i]['groupname']);
      response[i]['content'] = unescape(response[i]['content']);
      if (!response[i]['grouppic']) response[i]['grouppic'] = '/static/img/group.png';
      if (!response[i]['href']) response[i]['href'] = '/group/detail'+response[i]['id']+'.shtml';
    }
    callback(response);
  });
};
exports.blog = function(param, callback) {
  // 连接数据库
  var sqlite3 = require('sqlite3'),
    uedDb = new sqlite3.Database('./db/ued.db'),
    pageLen = 10;
  if (param && param['page']) {
    var page = param['page'];
  } else {
    var page = 1;
  }
  var limitStart = (page - 1) * pageLen;
  if (param && param['groupid']) {
    var countSql = 'select count(*) from blog,blogver where verid=blogver.id and groupid='+param['groupid'],
      sql = 'select blogid,addtime,blogpic,title,note from blog,blogver where verid=blogver.id and groupid='+param['groupid']+' order by blog.id desc limit '+limitStart+','+pageLen;
    blogFn(sql, countSql);
  } else if (param && param['userid']) {
    var blogidStr = '0',
      sql = 'select blogid from blogver where userid='+param['userid'];
    uedDb.all(sql, function (error, response){
      for (var i=0; i<response.length; i++) {
        blogidStr += ',' + response[i]['blogid'];
      }
      var countSql = 'select count(*) from blog,blogver where verid=blogver.id and blogid in('+blogidStr+')',
        sql = 'select blogid,addtime,blogpic,title,note from blog,blogver where verid=blogver.id and blogid in('+blogidStr+') order by blog.id desc limit '+limitStart+','+pageLen;
      blogFn(sql, countSql);
    });
  } else if (param && param['keyword']) {
    var keywords = param['keyword'].split('+');
    if (keywords.length) {
      var searchStr = '';
      for (var i=0; i<keywords.length; i++) {
        if (i > 0) {
          searchStr += " and ";
        }
        searchStr += "(title like '%"+keywords[i]+"%' or note like '%"+keywords[i]+"%')"
      }
      var countSql = 'select count(*) from blog,blogver where verid=blogver.id and '+searchStr,
        sql = 'select blogid,addtime,blogpic,title,note from blog,blogver where verid=blogver.id and '+searchStr+' order by blog.id desc limit '+limitStart+','+pageLen;
      blogFn(sql, countSql);
    }
  } else {
    var countSql = 'select count(*) from blog,blogver where verid=blogver.id',
      sql = 'select blogid,addtime,blogpic,title,note from blog,blogver where verid=blogver.id order by blog.id desc limit '+limitStart+','+pageLen;
    blogFn(sql, countSql);
  }
  function blogFn(sql, countSql){
    uedDb.all(sql, function (error, response){
      var blogList = [];
      function userListFn(){
        if (response.length) {
          var blog = response.shift();
          blog['title'] = unescape(blog['title']);
          blog['note'] = unescape(blog['note']);
          blog['addtime'] = blog['addtime'].split(' ')[0].replace(/-/g, '.');

          var sql = 'select userid,headpic,realname from blogver,user where blogver.userid=user.id and blogid='+blog['blogid']+' order by blogver.id';
          blog['user'] = {};
          blog['userlist'] = [];
          uedDb.all(sql, function (error, resuser){
            for (var j=0; j<resuser.length; j++) {
              var userid = resuser[j]['userid'];
              if (!blog['user'][userid]) {
                blog['user'][userid] = true;
                if (blog['userlist'].length < 3) {
                  blog['userlist'].push(resuser[j]);
                }
              }
            }
            blogList.push(blog);
            userListFn();
          });
        } else {
          uedDb.get(countSql, function (error, rescount){
            if (rescount) {
              var count = rescount['count(*)'];
            } else {
              var count = 0;
            }
            callback(blogList, count);
          });
        }
      }
      userListFn();
    });
  }
};
exports.user = function(callback) {
  // user
  var sqlite3 = require('sqlite3'),
    uedDb = new sqlite3.Database('./db/ued.db'),
    sql = 'select id,headpic,realname from user order by hot desc, id desc limit 0, 16';
  uedDb.all(sql, function (error, response){
    callback(response);
  });
};