exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'group': {},
    'blogCount': 0,
    'blogList': [],
    'groupList': [],
    'userList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      groupid = + getData['s'],
      page = + reqData['get']['page'];
    if (isNaN(groupid) || groupid <= 0) {
      resData['refresh'] = '/';
      resEnd(resData);
      return false;
    }
    if (isNaN(page) || page <= 0) page = 1;
    resData['page'] = page;
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'select * from usergroup where id='+groupid;
    uedDb.get(sql, function (error, response){
      if (response) {
        response['groupname'] = unescape(response['groupname']);
        response['content'] = unescape(response['content']);
        if (!response['grouppic']) response['grouppic'] = '/static/img/group.png';
        resData['group'] = response;
        commonFn();
      } else {
        resData['refresh'] = '/';
        resEnd(resData);
      }
    });
    function commonFn(){
      var common = require('../common');
      common.blog({'groupid':groupid,'page':page}, function (blogList, blogCount){
        resData['blogList'] = blogList;
        resData['blogCount'] = blogCount;
        common.group(function (groupList){
          resData['groupList'] = groupList;
          common.user(function (userList){
            resData['userList'] = userList;
            resEnd(resData);
          });
        });
      });
    }
  }
};