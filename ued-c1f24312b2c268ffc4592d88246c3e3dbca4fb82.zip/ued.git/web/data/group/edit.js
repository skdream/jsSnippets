exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'type': 'add',
    'group': {},
    'groupList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      groupid = + getData['s'];
    if (isNaN(groupid) || groupid <= 0) {
      groupid = 0;
      resData['group']['groupid'] = groupid;
      commonFn();
    } else {
      var sqlite3 = require('sqlite3'),
        uedDb = new sqlite3.Database('./db/ued.db'),
        sql = 'select * from usergroup where userid='+resData['user']['id']+' and id=' + groupid;
      uedDb.get(sql, function (error, response){
        if (response) {
          resData['type'] = 'edit';
          response['groupname'] = unescape(response['groupname']);
          response['content'] = unescape(response['content']);
          resData['group'] = response;
        } else {
          resData['group']['groupid'] = 0;
        }
        commonFn();
      });
    }
    function commonFn(){
      var common = require('../common');
      common.group(function (groupList){
        resData['groupList'] = groupList;
        resEnd(resData);
      });
    }
  }
};