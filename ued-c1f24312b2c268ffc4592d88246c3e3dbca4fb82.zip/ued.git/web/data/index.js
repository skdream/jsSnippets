exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'page': 1,
    'blogList': [],
    'blogCount': 0,
    'groupList': [],
    'userList': []
  };

  var uedcookie = require('./uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var page = + reqData['get']['page'];
    if (isNaN(page) || page <= 0) page = 1;
    resData['page'] = page;
    var common = require('./common');
    common.blog({'page':page}, function (blogList, blogCount){
      resData['blogList'] = blogList;
      resData['blogCount'] = blogCount;
      common.group(function (groupList){
        resData['groupList'] = groupList;
        common.user(function (userList){
          resData['userList'] = userList;
          resEnd(resData);
        });
      });
    });
  }
};