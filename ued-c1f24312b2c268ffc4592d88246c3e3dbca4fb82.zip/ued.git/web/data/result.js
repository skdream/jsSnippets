exports.fn = function(reqData, resEnd) {
  var resData = {},
    getData = reqData['get'];
  if (getData['msg']) {
    resData['msg'] = unescape(getData['msg']);
  }
  if (getData['goto']) {
    resData['goto'] = unescape(getData['goto']);
  }
  resEnd(resData);
};