exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'keyword': '',
    'group': {},
    'blogCount': 0,
    'blogList': [],
    'groupList': [],
    'userList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      keyword = getData['keyword'],
      page = + getData['page'],
      keywords = [];
    if (keyword) {
      keyword = unescape(keyword);
      keyword = keyword.replace(/(^\s+)|(\s+$)/g, '').replace(/\s+/g, ' ');
      resData['keyword'] = keyword;
      keyword = keyword.replace(/\s/g, '+');
      keywords = keyword.split('+');
      keyword = escape(keyword);

      if (isNaN(page) || page <= 0) page = 1;
      resData['page'] = page;
      commonFn();
    } else {
      resData['refresh'] = '/';
      resEnd(resData);
    }

    function redKeyword(str){
      for (var i=0; i<keywords.length; i++) {
        var newRegExp = new RegExp(keywords[i], 'gi');
        str = str.replace(newRegExp, '$'+keywords[i]+'$');
      }
      for (var i=0; i<keywords.length; i++) {
        var newRegExp = new RegExp('\\$'+keywords[i]+'\\$', 'gi');
        str = str.replace(newRegExp, '<em class="keyword">'+keywords[i]+'</em>');
      }
      return str;
    }
    
    function commonFn(){
      var common = require('../common');
      common.blog({'keyword':keyword,'page':page}, function (blogList, blogCount){
        if (blogList.length) {
          for(var i=0; i<blogList.length; i++) {
            blogList[i]['title'] = redKeyword(blogList[i]['title']);
            blogList[i]['note'] = redKeyword(blogList[i]['note']);
          }
        }
        resData['blogList'] = blogList;
        resData['blogCount'] = blogCount;
        common.group(function (groupList){
          resData['groupList'] = groupList;
          common.user(function (userList){
            resData['userList'] = userList;
            resEnd(resData);
          });
        });
      });
    }
  }
};