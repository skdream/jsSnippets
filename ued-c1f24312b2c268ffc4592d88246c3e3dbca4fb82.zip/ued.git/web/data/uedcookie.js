exports.fn = function(cookieData, callback) {
  var user = {
    'state': false
  }, userid = + cookieData['ued_userid'];
  if (isNaN(userid) || userid <= 0) {
    callback(user);
    return false;
  }
  var username = cookieData['ued_username'],
    usersign = cookieData['ued_usersign'];
  if (username && usersign) {
    // nothing
  } else {
    callback(user);
    return false;
  }

  // 连接数据库
  var sqlite3 = require('sqlite3'),
    dataDb = new sqlite3.Database('./db/ued.db');

  // 校验用户名密码
  var sql = 'select * from user where id='+userid+' and username="'+username+'" and usersign="'+usersign+'"';
  dataDb.get(sql, function(err, response){
    if (response) {
      user = response;
      user['state'] = true;
      callback(user);
    } else {
      callback(user);
    }
  });
};
