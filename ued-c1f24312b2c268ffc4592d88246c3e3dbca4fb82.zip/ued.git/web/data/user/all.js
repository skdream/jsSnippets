exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'userList': [],
    'groupList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    // 连接数据库
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'select id,headpic,realname from user order by hot desc, id desc';
    uedDb.all(sql, function (error, response){
      resData['userList'] = response;
      var common = require('../common');
      common.group(function (groupList){
        resData['groupList'] = groupList;
        resEnd(resData);
      });
    });
  }
};