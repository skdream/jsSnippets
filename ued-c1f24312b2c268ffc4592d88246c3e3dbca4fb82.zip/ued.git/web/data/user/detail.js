exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'iuser': {},
    'blogCount': 0,
    'blogList': [],
    'groupList': [],
    'userList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var getData = reqData['get'],
      userid = + getData['s'],
      page = + reqData['get']['page'];
    if (isNaN(userid) || userid <= 0) {
      resData['refresh'] = '/';
      resEnd(resData);
      return false;
    }
    if (isNaN(page) || page <= 0) page = 1;
    resData['page'] = page;
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'select id,headpic,realname from user where id='+userid;
    uedDb.get(sql, function (error, response){
      if (response) {
        resData['iuser'] = response;
        commonFn();
      } else {
        resData['refresh'] = '/';
        resEnd(resData);
      }
    });
    function commonFn(){
      var common = require('../common');
      common.blog({'userid':userid,'page':page}, function (blogList, blogCount){
        resData['blogList'] = blogList;
        resData['blogCount'] = blogCount;
        common.group(function (groupList){
          resData['groupList'] = groupList;
          common.user(function (userList){
            resData['userList'] = userList;
            resEnd(resData);
          });
        });
      });
    }
  }
};