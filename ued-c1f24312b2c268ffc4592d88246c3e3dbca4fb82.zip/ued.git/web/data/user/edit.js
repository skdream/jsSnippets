exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'user': {},
    'groupList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    var common = require('../common');
    common.group(function (groupList){
      resData['groupList'] = groupList;
      resEnd(resData);
    });
  }
};