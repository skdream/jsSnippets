exports.fn = function(reqData, resEnd) {
  // 初始数据
  var resData = {
    'logoList': []
  };

  var uedcookie = require('../uedcookie');
  uedcookie.fn(reqData['cookie'], function(user){
    if (user['state']) {
      resData['user'] = user;
      defaultFn();
    } else {
      resData['refresh'] = '/login.do';
      resEnd(resData);
    }
  });

  function defaultFn(){
    // 连接数据库
    var sqlite3 = require('sqlite3'),
      uedDb = new sqlite3.Database('./db/ued.db'),
      sql = 'select weblogo.id,url,headpic from weblogo,user where weblogo.userid=user.id order by weblogo.id';
    uedDb.all(sql, function (error, response){
      resData['logoList'] = response;
      resEnd(resData);
    });
  }
};