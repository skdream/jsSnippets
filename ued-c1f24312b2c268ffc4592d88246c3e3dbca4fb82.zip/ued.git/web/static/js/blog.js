// 编辑器
var editor = KindEditor.create('textarea[name="content"]', kindeditor_config);
// 文件上传
$('#blogpic').change(function(){
  var newfile = this.files[0];
  if (newfile) {
    var filesize = Math.ceil(newfile.size / 1024 / 1024 * 10) / 10;
    if (filesize > 1) {
      alert('选择的文件太大（'+filesize+'M），请压缩至1M以内再上传！');
      $(this).val('');
      $('#j-blogpic').html('');
      return false;
    }
    changefileFn(newfile, function (img){
      $('#j-blogpic').html(img);
    });
  } else {
    $('#j-blogpic').html('');
  }
});
function changefileFn(newfile, callback){
  var newFileReader = new FileReader();
  newFileReader.onload = function(){
    var newPic = new Image();
    newPic.src = this.result;
    callback(newPic); 
  };
  newFileReader.readAsDataURL(newfile);
}
// 表单提交
$('#j-form').submit(function (){
  editor.sync();
});

// 取消编辑
$('#j-free').click(function(){
  var blogid = + $('#j-blogid').val();
  if (isNaN(blogid) || blogid <= 0) {
    location.href = '/';
  } else {
    location.href = 'free.do?blogid='+blogid;
  }
});

