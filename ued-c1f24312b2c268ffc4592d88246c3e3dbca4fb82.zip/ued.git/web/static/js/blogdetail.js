// 选择版本
$('.ued-blogver .ver').hover(function (){
  $(this).addClass('verhover');
}, function (){
  $(this).removeClass('verhover');
});
$('.ued-blogver .ver li').click(function(){
  var href = $(this).data('href');
  if (href != '#') location.href = href;
});
// 获取评论列表
var blogid = $('#j-blogid').val(),
  page = 0;
function remarkFn(){
  page ++;
  $.ajax({
    type: 'post',
    url: 'remark.do',
    dataType: 'json',
    data: {blogid: blogid, page: page},
    success: function (res){
      var remarkList = res['remarkList'],
        remarkBackList = res['remarkBackList'],
        comeon = res['comeon'];
      remarkBackDict = {};
      $.each(remarkBackList, function (){
        var remarkid = this['remarkid'];
        if (!remarkBackDict[remarkid]) remarkBackDict[remarkid] = [];
        remarkBackDict[remarkid].push(this);
      });
      $.each(remarkList, function (){
        // 回复列表
        var remarkbackContent = '';
        if (remarkBackDict[this['id']] && remarkBackDict[this['id']].length) {
          $.each(remarkBackDict[this['id']], function (){
            remarkbackContent += '<div class="line"><span class="uname">'+this['realname']+'：</span>'+this['content']+'<div class="date">'+this['addtime']+'</div></div>';
          });
        }
        var liObj = $('<li>\
          <div class="headpic"><a target="_blank" href="/user/detail'+this['userid']+'.shtml" title="'+this['realname']+'"><img src="'+this['headpic']+'" alt="'+this['realname']+'"></a></div>\
          <div class="content">\
            <div class="mline">'+this['content']+'<div class="date">'+this['addtime']+'</div></div>\
            <div id="j-remarkback-'+this['id']+'">'+remarkbackContent+'</div>\
            <div class="back fn-clear">\
              <a class="j-back" href="javascript:void(0)">回复</a>\
              <div class="fn-hide">\
                <form target="remarkframe" method="post" action="remarkadd.do">\
                <input type="hidden" name="blogid" value="'+blogid+'">\
                <input type="hidden" name="remarkid" value="'+this['id']+'">\
                <textarea name="content"></textarea>\
                <input type="submit" value="提交">\
                </form>\
              </div>\
            </div>\
          </div>\
        </li>');
        // 回复
        liObj.find('.j-back').click(function(){
          $(this).hide();
          $(this).next().show();
          $(this).next().find('textarea').focus();
        });
        $('#j-remarklist').append(liObj);
      });
      if (comeon) {
        $('#j-remarkmore').show();
      } else {
        $('#j-remarkmore').hide();
      }
      $('#j-remarklist').height('auto');
    },
    error: function (){
      alert('服务器连接超时，请稍后再试！');
    }
  });
}
remarkFn();
// 加载更多评论
$('#j-remarkmore').click(function (){
  remarkFn();
});
// 获取评论回复
function remarkBackFn(remarkid){
  var remarkBackObj = $('#j-remarkback-'+remarkid),
    backform = remarkBackObj.next();
  backform.find('textarea').val('');
  backform.find('.j-back').next().hide();
  backform.find('.j-back').show();
  $.ajax({
    type: 'post',
    url: 'remarkback.do',
    dataType: 'json',
    data: {remarkid: remarkid},
    success: function (res){
      remarkBackObj.height(remarkBackObj.height());
      remarkBackObj.html('');
      var remarkBackList = res['remarkBackList'];
      $.each(remarkBackList, function(){
        remarkBackObj.append('<div class="line"><span class="uname">'+this['realname']+'：</span>'+this['content']+'<div class="date">'+this['addtime']+'</div></div>');
      });
      remarkBackObj.height('auto');
    },
    error: function (){
      alert('服务器连接超时，请稍后再试！');
    }
  });
}
// 刷新评论列表
function remarkRefresh(remarkid){
  if (remarkid && remarkid > 0) {
    remarkBackFn(remarkid);
  } else {
    $('#j-remarkadd textarea').val('');
    $('#j-remarklist').height($('#j-remarklist').height());
    $('#j-remarklist').html('');
    page = 0;
    remarkFn();
  }
}