// 分页
(function(){
  var listlen = + $('#j-page').data('listlen'),
    pageurl = $('#j-page').data('url'),
    pagecount = Math.ceil((+ $('#j-page').data('count')) / listlen);
  if (pageurl) {
    pageurl += '&';
  } else {
    pageurl = '?';
  }
  if (pagecount > 1) {
    var page = + $('#j-page').data('page'),
      pageStart = 1,
      pageEnd = pagecount;
    if (page > 1) {
      $('#j-page').append('<a href="'+pageurl+'page='+(page-1)+'">&lt;</a>');
    }
    if (pagecount > 11) {
      if (page < 6) {
        pageStart = 1;
        pageEnd = 11;
      } else if (pageEnd > (pagecount - 5)) {
        pageEnd = pagecount;
        pageStart = pagecount - 10;
      } else {
        pageStart = page - 5;
        pageEnd = page + 5;
      }
    }
    for (var i=pageStart; i<=pageEnd; i++) {
      if (i == page) {
        $('#j-page').append('<a class="current" href="'+pageurl+'page='+i+'">'+i+'</a>');
      } else {
        $('#j-page').append('<a href="'+pageurl+'page='+i+'">'+i+'</a>');
      }
    }
    if (page < pagecount) {
      $('#j-page').append('<a href="'+pageurl+'page='+(page+1)+'">&gt;</a>');
    }
  }
})();