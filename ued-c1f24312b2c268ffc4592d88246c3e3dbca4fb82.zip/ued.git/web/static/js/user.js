// 文件上传
$('#headpic').change(function(){
  var newfile = this.files[0];
  if (newfile) {
    var filesize = Math.ceil(newfile.size / 1024 / 1024 * 10) / 10;
    if (filesize > 1) {
      alert('选择的文件太大（'+filesize+'M），请压缩至1M以内再上传！');
      $(this).val('');
      $('#j-headpic').html('');
      return false;
    }
    changefileFn(newfile, function (img){
      $('#j-headpic').html(img);
    });
  } else {
    $('#j-headpic').html('');
  }
});
function changefileFn(newfile, callback){
  var newFileReader = new FileReader();
  newFileReader.onload = function(){
    var newPic = new Image();
    newPic.src = this.result;
    callback(newPic); 
  };
  newFileReader.readAsDataURL(newfile);
}