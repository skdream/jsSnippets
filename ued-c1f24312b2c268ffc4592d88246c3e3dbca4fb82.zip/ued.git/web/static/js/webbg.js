// 选择bg
$('.ued-webbg li').click(function (){
  $(this).addClass('selected')
    .siblings().removeClass('selected');
});
$('.j-select').click(function (){
  location.href = 'selectbg.do?id='+$(this).data('id');
});
$('#j-addform').submit(function() {
  if ($('#j-upbg').val()) {
    return true;
  } else {
    alert('请选择文件');
    return false;
  }
});
$('#j-addform .btn').click(function (){
  $('#j-addform').submit();
});

// 文件上传
$('#j-upbg').change(function(){
  var newfile = this.files[0];
  if (newfile) {
    var filesize = Math.ceil(newfile.size / 1024 / 1024 * 10) / 10;
    if (filesize > 1) {
      alert('选择的文件太大（'+filesize+'M），请压缩至1M以内再上传！');
      $(this).val('');
      $('#j-upshow').removeClass('has').html('');
      return false;
    }
    changefileFn(newfile, function (img){
      $('#j-upshow').addClass('has').html(img);
    });
  } else {
    $('#j-upshow').removeClass('has').html('');
  }
});
function changefileFn(newfile, callback){
  var newFileReader = new FileReader();
  newFileReader.onload = function(){
    var newPic = new Image();
    newPic.src = this.result;
    newPic.onload = newPic.onerror = function (){
      if (newPic.width >= 800) {
        $('#j-upbgsize').val('100%');
      } else {
        $('#j-upbgsize').val('auto');
      }
      callback(newPic);
    }
  };
  newFileReader.readAsDataURL(newfile);
}