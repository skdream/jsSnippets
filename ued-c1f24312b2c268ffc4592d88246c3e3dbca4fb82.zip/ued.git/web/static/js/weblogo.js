// 选择logo
$('.ued-weblogo li').click(function (){
  $(this).addClass('selected')
    .siblings().removeClass('selected');
});
$('.j-select').click(function (){
  location.href = 'selectlogo.do?id='+$(this).data('id');
});
$('#j-addform').submit(function() {
  if ($('#j-uplogo').val()) {
    return true;
  } else {
    alert('请选择文件');
    return false;
  }
});
$('#j-addform .btn').click(function (){
  $('#j-addform').submit();
});

// 文件上传
$('#j-uplogo').change(function(){
  var newfile = this.files[0];
  if (newfile) {
    var filesize = Math.ceil(newfile.size / 1024 / 1024 * 10) / 10;
    if (filesize > 1) {
      alert('选择的文件太大（'+filesize+'M），请压缩至1M以内再上传！');
      $(this).val('');
      $('#j-upshow').removeClass('has').html('');
      return false;
    }
    changefileFn(newfile, function (img){
      $('#j-upshow').addClass('has').html(img);
    });
  } else {
    $('#j-upshow').removeClass('has').html('');
  }
});
function changefileFn(newfile, callback){
  var newFileReader = new FileReader();
  newFileReader.onload = function(){
    var newPic = new Image();
    newPic.src = this.result;
    callback(newPic); 
  };
  newFileReader.readAsDataURL(newfile);
}